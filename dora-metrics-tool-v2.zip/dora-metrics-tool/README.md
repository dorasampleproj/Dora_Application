

---
## Upgrades (v2)
- **GitHub**: Actions validation (runs/jobs) + GraphQL commit→PR mapping for lead time.
- **Jira**: Lead time from issue **status changelog** (cycle time from `JIRA_CYCLE_START` → `JIRA_CYCLE_END`).
- **ServiceNow**: Incident ingestion via **Table API** with fields/time window configurable.
- **Databricks**: Treat selected **Jobs runs** as deployments with duration & status.
- **Excel/CSV**: Header‑tolerant normalization for deployments/incidents.

Update `backend/.env` using `.env.sample` for the new variables and restart the backend.
