
const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx');

function readTabular(filePath) {
  if (!fs.existsSync(filePath)) return [];
  const ext = path.extname(filePath).toLowerCase();
  const wb = XLSX.readFile(filePath); // works for csv/xlsx
  const ws = wb.Sheets[wb.SheetNames[0]];
  return XLSX.utils.sheet_to_json(ws, { defval: null });
}

function normalizeDeploymentRow(r) {
  const id  = r.id || r.ID || r.DeploymentId || r.deployment_id || null;
  const ts  = r.timestamp || r.Timestamp || r.date || r.deploy_time || null;
  const st  = r.status || r.Status || r.state || process.env.EXCEL_DEPLOYMENT_STATUS_FIELD || 'success';
  return id && ts ? { id: String(id), timestamp: ts, status: String(st).toLowerCase() } : null;
}

function normalizeIncidentRow(r) {
  const id  = r.id || r.IncidentId || r.incident_id || r.number || null;
  const dep = r.deploymentId || r.DeploymentId || r.deployment_id || null;
  const startedAt  = r.startedAt || r.StartedAt || r.opened_at || r.opened || r.start || null;
  const resolvedAt = r.resolvedAt || r.ResolvedAt || r.closed_at || r.closed || r.end || null;
  return id && startedAt ? { id: String(id), deploymentId: dep, startedAt, resolvedAt } : null;
}

async function fetchDeployments() {
  const p = process.env.EXCEL_DEPLOYMENTS_FILE;
  if (!p) return [];
  return readTabular(p).map(normalizeDeploymentRow).filter(Boolean);
}

async function fetchIncidents() {
  const p = process.env.EXCEL_INCIDENTS_FILE;
  if (!p) return [];
  return readTabular(p).map(normalizeIncidentRow).filter(Boolean);
}

module.exports = { name: 'excel', fetchDeployments, fetchIncidents };
