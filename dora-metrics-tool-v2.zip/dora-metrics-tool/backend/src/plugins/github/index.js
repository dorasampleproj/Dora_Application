
const axios = require('axios');
const { generateDemoDeployments, generateDemoIncidents, generateDemoLeadTimes } = require('../shared/demo');

const USE_DEMO = (process.env.USE_DEMO_DATA || 'true') === 'true';

const token = process.env.GITHUB_TOKEN;
const org = process.env.GITHUB_ORG;
const repos = (process.env.GITHUB_REPOS || '').split(',').map((x) => x.trim()).filter(Boolean);
const deploymentEnvironment = process.env.GITHUB_ENV || 'production';

const api = axios.create({
  baseURL: 'https://api.github.com',
  headers: {
    Authorization: `Bearer ${token}`,
    Accept: 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
  },
});

async function paginatedGet(url) {
  let page = 1;
  const results = [];
  while (true) {
    const { data } = await api.get(url, { params: { per_page: 100, page } });
    if (!Array.isArray(data) || data.length === 0) break;
    results.push(...data);
    page++;
  }
  return results;
}

async function fetchDeployments() {
  if (USE_DEMO) return generateDemoDeployments();
  if (!token || !org || repos.length === 0) return [];
  const all = [];
  for (const repo of repos) {
    const deployments = await paginatedGet(`/repos/${org}/${repo}/deployments`);
    for (const dep of deployments) {
      if (deploymentEnvironment && dep.environment && dep.environment !== deploymentEnvironment) continue;
      const statuses = await paginatedGet(`/repos/${org}/${repo}/deployments/${dep.id}/statuses`);
      const latest = statuses[0] || {};
      const status = latest.state || 'unknown';
      // attempt Actions validation if commit sha present
      let ci = { validated: false };
      if (dep.sha) {
        try {
          ci = await getActionsValidationForSHA(repo, dep.sha);
        } catch (e) {
          ci = { validated: false };
        }
      }
      all.push({
        id: `${repo}-${dep.id}`,
        repo,
        environment: dep.environment,
        sha: dep.sha,
        ref: dep.ref,
        timestamp: dep.created_at,
        status,
        ci,
      });
    }
  }
  return all;
}

async function getActionsValidationForSHA(repo, sha) {
  const { data: runsResp } = await api.get(`/repos/${org}/${repo}/actions/runs`, {
    params: { head_sha: sha, status: 'completed', per_page: 100 },
  });
  const runs = runsResp.workflow_runs || [];
  const successful = runs
    .filter((r) => r.conclusion === 'success')
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  const selected = successful[0] || runs[0];
  if (!selected) return { validated: false };
  const jobsResp = await api.get(`/repos/${org}/${repo}/actions/runs/${selected.id}/jobs`, { params: { per_page: 100 } });
  const jobs = jobsResp.data.jobs || [];
  const parsed = jobs.map((j) => {
    const dur = Math.max(0, (new Date(j.completed_at) - new Date(j.started_at)) / 1000);
    return { id: j.id, name: j.name, status: j.status, conclusion: j.conclusion, startedAt: j.started_at, completedAt: j.completed_at, durationSec: Math.round(dur) };
  });
  const totalSec = parsed.reduce((s, j) => s + j.durationSec, 0);
  const allSuccessful = parsed.every((j) => j.conclusion === 'success');
  return {
    validated: selected.conclusion === 'success' && allSuccessful,
    runId: selected.id,
    runHtmlUrl: selected.html_url,
    runCreatedAt: selected.created_at,
    runUpdatedAt: selected.updated_at,
    wallClockSec: Math.max(0, (new Date(selected.updated_at) - new Date(selected.created_at)) / 1000),
    totalJobDurationSec: totalSec,
    jobs: parsed,
  };
}

async function fetchLeadTimeData() {
  if (USE_DEMO) return generateDemoLeadTimes();
  if (!token || !org || repos.length === 0) return [];
  const leadTimes = [];
  const deployments = await fetchDeployments();
  for (const repo of repos) {
    for (const dep of deployments.filter(d => d.repo === repo)) {
      if (!dep.sha) continue;
      let pr = null;
      try { pr = await getAssociatedPRForSHA(repo, dep.sha); } catch {}
      if (!pr) { try { pr = await getAssociatedPRViaREST(repo, dep.sha); } catch {} }
      if (!pr || !pr.mergedAt) continue;
      const minutes = (new Date(dep.timestamp) - new Date(pr.mergedAt)) / 60000;
      if (minutes >= 0) leadTimes.push({ hours: +(minutes/60).toFixed(2) });
    }
  }
  return leadTimes;
}

async function getAssociatedPRForSHA(repo, sha) {
  const gql = await axios.create({
    baseURL: 'https://api.github.com/graphql',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
  });
  const query = `query($org:String!,$repo:String!,$sha:String!){
    repository(owner:$org,name:$repo){
      commit: object(expression:$sha){
        ... on Commit {
          associatedPullRequests(first:5, orderBy:{field:CREATED_AT,direction:DESC}){
            nodes{ number mergedAt state url }
          }
        }
      }
    }
  }`;
  const { data } = await gql.post('', { query, variables: { org, repo, sha } });
  const nodes = data?.data?.repository?.commit?.associatedPullRequests?.nodes || [];
  const merged = nodes.find(n=>!!n.mergedAt);
  return merged || nodes[0] || null;
}

async function getAssociatedPRViaREST(repo, sha) {
  const { data } = await api.get(`/repos/${org}/${repo}/commits/${sha}/pulls`, { params: { per_page: 10 } });
  const merged = (data||[]).find(pr => !!pr.merged_at);
  if (merged) return { number: merged.number, state: (merged.state||'').toUpperCase(), mergedAt: merged.merged_at, url: merged.html_url };
  const first = (data||[])[0];
  return first ? { number: first.number, state: (first.state||'').toUpperCase(), mergedAt: first.merged_at, url: first.html_url } : null;
}

async function fetchIncidents() {
  if (USE_DEMO) {
    const deps = await fetchDeployments();
    return generateDemoIncidents(deps);
  }
  const deployments = await fetchDeployments();
  return deployments
    .filter((d) => d.status === 'failure' || d.status === 'failed' || (d.ci && !d.ci.validated))
    .map((d) => ({ id: `fail-${d.id}`, deploymentId: d.id, startedAt: d.timestamp, resolvedAt: d.timestamp }));
}

module.exports = { name: 'github', fetchDeployments, fetchLeadTimeData, fetchIncidents };
