
const axios = require('axios');

const USE_DEMO = (process.env.USE_DEMO_DATA || 'true') === 'true';

async function fetchIncidents() {
  if (USE_DEMO) {
    const { generateDemoDeployments, generateDemoIncidents } = require('../shared/demo');
    return generateDemoIncidents(generateDemoDeployments());
  }

  const base = process.env.SERVICENOW_INSTANCE;
  const user = process.env.SERVICENOW_USER;
  const password = process.env.SERVICENOW_PASSWORD;
  const table = process.env.SERVICENOW_TABLE || 'incident';
  const query = process.env.SERVICENOW_QUERY || 'active=true';
  const fields = process.env.SERVICENOW_FIELDS || 'number,opened_at,resolved_at,closed_at,state,sys_id';
  const limit = Number(process.env.SERVICENOW_LIMIT || 200);

  if (!base || !user || !password) return [];

  const api = axios.create({ baseURL: `${base}/api/now/table/${table}`, auth: { username: user, password } });

  const { data } = await api.get('', { params: { sysparm_query: query, sysparm_fields: fields, sysparm_limit: limit } });
  const result = (data?.result || []).map(r => ({
    id: r.number || r.sys_id,
    startedAt: r.opened_at,
    resolvedAt: r.resolved_at || r.closed_at,
    state: r.state
  }));
  return result;
}

module.exports = { name: 'servicenow', fetchIncidents };
