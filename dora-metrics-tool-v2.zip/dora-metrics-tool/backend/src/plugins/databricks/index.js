
const axios = require('axios');

const USE_DEMO = (process.env.USE_DEMO_DATA || 'true') === 'true';

function mapEnv(jobId, def='production') {
  const map = (process.env.DATABRICKS_JOB_ENV_MAP || '')
    .split(',').map(s=>s.trim()).filter(Boolean)
    .reduce((acc, kv) => { const [k,v] = kv.split(':'); acc[k]=v; return acc; }, {});
  return map[jobId] || def;
}

async function fetchDeployments() {
  if (USE_DEMO) {
    const { generateDemoDeployments } = require('../shared/demo');
    return generateDemoDeployments();
  }

  const host = process.env.DATABRICKS_HOST;
  const token = process.env.DATABRICKS_TOKEN;
  const jobIds = (process.env.DATABRICKS_JOB_IDS || '').split(',').map(s=>s.trim()).filter(Boolean);
  if (!host || !token) return [];

  const api = axios.create({ baseURL: `${host}/api/2.2`, headers: { Authorization: `Bearer ${token}` } });

  const deployments = [];
  for (const jobId of jobIds) {
    const { data } = await api.get('/jobs/runs/list', { params: { job_id: jobId, limit: 25, completed_only: true } });
    for (const run of (data.runs || [])) {
      const startMs = run.start_time; const endMs = run.end_time || startMs;
      const result = (run.state && (run.state.result_state || run.state.life_cycle_state) || 'unknown').toLowerCase();
      const status = result === 'success' ? 'success' : result;
      deployments.push({
        id: `job-${jobId}-run-${run.run_id}`,
        repo: `databricks-job-${jobId}`,
        environment: mapEnv(String(jobId)),
        sha: run.git_source?.git_commit || null,
        ref: run.git_source?.git_branch || null,
        timestamp: new Date(startMs).toISOString(),
        status,
        ci: {
          validated: status === 'success',
          runId: run.run_id,
          runHtmlUrl: run.run_page_url,
          wallClockSec: startMs && endMs ? Math.max(0, Math.round((endMs - startMs)/1000)) : 0,
          jobs: []
        }
      });
    }
  }

  return deployments;
}

module.exports = { name: 'databricks', fetchDeployments };
