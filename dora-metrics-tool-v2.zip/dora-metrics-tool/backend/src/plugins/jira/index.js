
const axios = require('axios');
const dayjs = require('dayjs');

const USE_DEMO = (process.env.USE_DEMO_DATA || 'true') === 'true';

async function fetchLeadTimeData() {
  if (USE_DEMO) {
    const { generateDemoLeadTimes } = require('../shared/demo');
    return generateDemoLeadTimes();
  }

  const base = process.env.JIRA_BASE_URL;
  const email = process.env.JIRA_USER_EMAIL;
  const token = process.env.JIRA_API_TOKEN;
  const jql = process.env.JIRA_JQL || 'project = ABC AND statusCategory = Done ORDER BY updated DESC';
  const pageSize = Number(process.env.JIRA_PAGE_SIZE || 50);
  const startStatus = process.env.JIRA_CYCLE_START || 'In Progress';
  const endStatus = process.env.JIRA_CYCLE_END || 'Done';

  if (!base || !email || !token) return [];

  const api = axios.create({ baseURL: base, auth: { username: email, password: token } });

  let startAt = 0; const leadTimes = [];
  while (true) {
    const { data } = await api.get('/rest/api/3/search', {
      params: { jql, startAt, maxResults: pageSize, expand: 'changelog', fields: 'key,status,created,resolutiondate' }
    });
    const issues = data.issues || []; if (issues.length === 0) break;

    for (const issue of issues) {
      const histories = issue?.changelog?.histories || [];
      let lastStart = null; let lastEnd = null;
      for (const h of histories) {
        const when = h.created;
        for (const item of (h.items || [])) {
          if (item.field === 'status') {
            if (item.toString === startStatus) lastStart = when;
            if (item.toString === endStatus)   lastEnd   = when;
          }
        }
      }
      if (lastStart && lastEnd && dayjs(lastEnd).isAfter(dayjs(lastStart))) {
        const minutes = dayjs(lastEnd).diff(dayjs(lastStart), 'minute');
        leadTimes.push({ hours: +(minutes/60).toFixed(2) });
      } else if (issue.fields?.created && issue.fields?.resolutiondate) {
        const minutes = dayjs(issue.fields.resolutiondate).diff(dayjs(issue.fields.created), 'minute');
        leadTimes.push({ hours: +(minutes/60).toFixed(2) });
      }
    }

    startAt += issues.length; if (startAt >= (data.total || 0)) break;
  }

  return leadTimes;
}

module.exports = { name: 'jira', fetchLeadTimeData };
