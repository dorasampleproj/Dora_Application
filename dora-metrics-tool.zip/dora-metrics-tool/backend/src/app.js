
const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');

dotenv.config();

const metricsRoutes = require('./routes/metrics.routes');

const app = express();

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
app.use(cors({ origin: (origin, cb) => {
  if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) return cb(null, true);
  return cb(new Error('Not allowed by CORS'));
}}));

app.get('/api/healthz', (req, res) => res.json({ ok: true }));
app.use('/api', metricsRoutes);

module.exports = app;
