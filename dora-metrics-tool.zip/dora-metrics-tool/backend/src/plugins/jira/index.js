
const axios = require('axios');
const { generateDemoLeadTimes } = require('../shared/demo');

const USE_DEMO = (process.env.USE_DEMO_DATA || 'true') === 'true';

async function fetchLeadTimeData() {
  if (USE_DEMO) return generateDemoLeadTimes();
  const base = process.env.JIRA_BASE_URL;
  const email = process.env.JIRA_USER_EMAIL;
  const token = process.env.JIRA_API_TOKEN;
  const jql = process.env.JIRA_JQL || 'project = ABC and statusCategory = Done order by updated desc';
  if (!base || !email || !token) return [];

  const api = axios.create({ baseURL: base, auth: { username: email, password: token } });
  const { data } = await api.get('/rest/api/3/search', { params: { jql, maxResults: 50, fields: 'created,resolutiondate' } });
  const issues = data.issues || [];
  return issues.filter(i => i.fields && i.fields.resolutiondate).map(i => {
    const created = new Date(i.fields.created);
    const resolved = new Date(i.fields.resolutiondate);
    const hours = (resolved - created) / 36e5;
    return { hours };
  });
}

module.exports = { name: 'jira', fetchLeadTimeData };
