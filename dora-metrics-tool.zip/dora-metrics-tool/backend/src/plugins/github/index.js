
const axios = require('axios');
const { generateDemoDeployments, generateDemoIncidents, generateDemoLeadTimes } = require('../shared/demo');

const USE_DEMO = (process.env.USE_DEMO_DATA || 'true') === 'true';

async function fetchDeployments() {
  if (USE_DEMO) return generateDemoDeployments();
  const token = process.env.GITHUB_TOKEN;
  const org = process.env.GITHUB_ORG;
  const repo = process.env.GITHUB_REPO;
  if (!token || !org || !repo) return [];

  const api = axios.create({
    baseURL: `https://api.github.com/repos/${org}/${repo}`,
    headers: { Authorization: `Bearer ${token}`, 'X-GitHub-Api-Version': '2022-11-28' }
  });

  // Fetch recent deployments (placeholder; production should paginate)
  const { data } = await api.get('/deployments');
  return data.map(d => ({ id: d.id, timestamp: d.created_at, status: d.status || 'success' }));
}

async function fetchIncidents() {
  if (USE_DEMO) {
    const deps = await fetchDeployments();
    return generateDemoIncidents(deps);
  }
  // GitHub itself doesn't model incidents; you might map from issues with label 'incident'
  return [];
}

async function fetchLeadTimeData() {
  if (USE_DEMO) return generateDemoLeadTimes();
  // Approximate lead time via PR merged_at -> deployment time (requires correlation). Left as exercise.
  return [];
}

module.exports = { name: 'github', fetchDeployments, fetchIncidents, fetchLeadTimeData };
