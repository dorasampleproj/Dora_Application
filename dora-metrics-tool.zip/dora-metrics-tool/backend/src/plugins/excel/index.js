
const XLSX = require('xlsx');
const fs = require('fs');

function readSheetRows(filePath, sheetName) {
  if (!fs.existsSync(filePath)) return [];
  const wb = XLSX.readFile(filePath);
  const ws = wb.Sheets[sheetName || wb.SheetNames[0]];
  return XLSX.utils.sheet_to_json(ws, { defval: null });
}

async function fetchDeployments() {
  const path = process.env.EXCEL_DEPLOYMENTS_FILE;
  if (!path) return [];
  const rows = readSheetRows(path);
  return rows.map(r => ({ id: String(r.id || r.ID || r.DeploymentId), timestamp: r.timestamp || r.date || r.Timestamp, status: r.status || 'success' }));
}

async function fetchIncidents() {
  const path = process.env.EXCEL_INCIDENTS_FILE;
  if (!path) return [];
  const rows = readSheetRows(path);
  return rows.map(r => ({ id: String(r.id || r.IncidentId), deploymentId: r.deploymentId || r.DeploymentId, startedAt: r.startedAt || r.StartedAt, resolvedAt: r.resolvedAt || r.ResolvedAt }));
}

module.exports = { name: 'excel', fetchDeployments, fetchIncidents };
