
const axios = require('axios');
const { generateDemoIncidents, generateDemoDeployments } = require('../shared/demo');

const USE_DEMO = (process.env.USE_DEMO_DATA || 'true') === 'true';

async function fetchIncidents() {
  if (USE_DEMO) {
    const deps = generateDemoDeployments();
    return generateDemoIncidents(deps);
  }
  const instance = process.env.SERVICENOW_INSTANCE; // e.g., https://devXXXXX.service-now.com
  const user = process.env.SERVICENOW_USER;
  const password = process.env.SERVICENOW_PASSWORD;
  const table = process.env.SERVICENOW_TABLE || 'incident';
  if (!instance || !user || !password) return [];

  const api = axios.create({ baseURL: `${instance}/api/now/table/${table}`, auth: { username: user, password } });
  const { data } = await api.get('', { params: { sysparm_limit: 100, sysparm_fields: 'number,opened_at,resolved_at,closed_at' } });
  const result = data.result || [];
  return result.filter(r => r.opened_at && (r.resolved_at || r.closed_at)).map(r => ({
    id: r.number,
    startedAt: r.opened_at,
    resolvedAt: r.resolved_at || r.closed_at
  }));
}

module.exports = { name: 'servicenow', fetchIncidents };
