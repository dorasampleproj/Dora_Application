
const axios = require('axios');
const { generateDemoDeployments } = require('../shared/demo');

const USE_DEMO = (process.env.USE_DEMO_DATA || 'true') === 'true';

async function fetchDeployments() {
  if (USE_DEMO) return generateDemoDeployments();
  const host = process.env.DATABRICKS_HOST; // e.g., https://adb-xxxx.azuredatabricks.net
  const token = process.env.DATABRICKS_TOKEN;
  if (!host || !token) return [];
  const api = axios.create({ baseURL: `${host}/api/2.1`, headers: { Authorization: `Bearer ${token}` } });

  // Example: map successful job runs as deployments (placeholder)
  const { data } = await api.get('/jobs/list');
  const jobs = data.jobs || [];
  return jobs.slice(0, 20).map((j, idx) => ({ id: `job-${j.job_id}-${idx}`, timestamp: new Date().toISOString(), status: 'success' }));
}

module.exports = { name: 'databricks', fetchDeployments };
