
const dayjs = require('dayjs');

function generateDemoDeployments(days = 28) {
  const out = [];
  for (let i = days; i >= 0; i--) {
    const date = dayjs().subtract(i, 'day');
    const count = Math.floor(Math.random()*3)+1; // 1..3 per day
    for (let j=0;j<count;j++) {
      out.push({ id: `${date.format('YYYYMMDD')}-${j}`, timestamp: date.add(j, 'hour').toISOString(), status: Math.random()<0.1 ? 'failed' : 'success' });
    }
  }
  return out;
}

function generateDemoIncidents(deployments) {
  // 10% of deployments cause an incident lasting 15-180 minutes
  return deployments.filter(()=>Math.random()<0.1).map(d => {
    const startedAt = dayjs(d.timestamp).add(10, 'minute');
    const dur = 15 + Math.floor(Math.random()*165);
    return { id: `inc-${d.id}`, deploymentId: d.id, startedAt: startedAt.toISOString(), resolvedAt: startedAt.add(dur, 'minute').toISOString() };
  });
}

function generateDemoLeadTimes(count = 80) {
  return Array.from({length: count}).map(()=>({ hours: +(2 + Math.random()*60).toFixed(1) }));
}

module.exports = { generateDemoDeployments, generateDemoIncidents, generateDemoLeadTimes };
