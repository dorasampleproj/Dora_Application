
const { getDoraMetrics, getPluginsInfo } = require('../core/metrics-engine');

exports.getMetrics = async (req, res) => {
  try {
    const metrics = await getDoraMetrics();
    res.json(metrics);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to compute metrics', details: err.message });
  }
};

exports.getPlugins = async (req, res) => {
  try {
    const info = await getPluginsInfo();
    res.json(info);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to list plugins', details: err.message });
  }
};
