
const router = require('express').Router();
const controller = require('../controllers/metrics.controller');

router.get('/metrics', controller.getMetrics);
router.get('/plugins', controller.getPlugins);

module.exports = router;
