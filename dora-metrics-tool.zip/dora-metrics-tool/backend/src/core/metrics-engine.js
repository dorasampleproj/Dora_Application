
const dayjs = require('dayjs');
const { loadPlugins } = require('./plugin-manager');

function mergeArrays(arrs) {
  return arrs.flat().filter(Boolean);
}

function calcDeploymentFrequency(deployments) {
  // Expect deployments: [{id, timestamp, status}]
  const days = {};
  deployments.forEach(d => {
    const day = dayjs(d.timestamp).format('YYYY-MM-DD');
    days[day] = (days[day] || 0) + 1;
  });
  const series = Object.keys(days).sort().map(date => ({ date, count: days[date] }));
  const total = series.reduce((a, b) => a + b.count, 0);
  const daysCount = series.length || 1;
  return {
    valuePerDay: +(total / daysCount).toFixed(2),
    series
  };
}

function calcLeadTime(leadTimes) {
  // Expect leadTimes: [{hours}]
  const arr = leadTimes.map(x => x.hours).filter(n => Number.isFinite(n));
  if (arr.length === 0) return { avgHours: 0, p50: 0, p90: 0 };
  const sum = arr.reduce((a,b)=>a+b,0);
  const sorted = [...arr].sort((a,b)=>a-b);
  const p = q => sorted[Math.floor((q/100)*(sorted.length-1))];
  return {
    avgHours: +(sum/arr.length).toFixed(2),
    p50: +p(50).toFixed(2),
    p90: +p(90).toFixed(2)
  };
}

function calcChangeFailureRate(deployments, incidents) {
  // failed deployments inferred by incidents referencing deploymentId or status === 'failed'
  const failedFromStatus = deployments.filter(d => d.status === 'failed').length;
  const failedFromIncidents = new Set(incidents.map(i => i.deploymentId).filter(Boolean));
  const failed = failedFromStatus + failedFromIncidents.size;
  const total = deployments.length || 1;
  return { rate: +(100 * failed / total).toFixed(2), failed, total };
}

function calcMTTR(incidents) {
  // incidents: [{startedAt, resolvedAt}]
  const durations = incidents
    .filter(i => i.startedAt && i.resolvedAt)
    .map(i => dayjs(i.resolvedAt).diff(dayjs(i.startedAt), 'minute'));
  if (durations.length === 0) return { minutes: 0 };
  const avg = durations.reduce((a,b)=>a+b,0)/durations.length;
  return { minutes: +avg.toFixed(1) };
}

async function getDoraMetrics() {
  const plugins = loadPlugins();

  const deploymentsArr = [];
  const incidentsArr = [];
  const leadTimesArr = [];

  for (const p of plugins) {
    if (p.fetchDeployments) deploymentsArr.push(await p.fetchDeployments());
    if (p.fetchIncidents) incidentsArr.push(await p.fetchIncidents());
    if (p.fetchLeadTimeData) leadTimesArr.push(await p.fetchLeadTimeData());
  }

  const deployments = mergeArrays(deploymentsArr);
  const incidents = mergeArrays(incidentsArr);
  const leadTimes = mergeArrays(leadTimesArr);

  const deploymentFrequency = calcDeploymentFrequency(deployments);
  const leadTime = calcLeadTime(leadTimes);
  const changeFailureRate = calcChangeFailureRate(deployments, incidents);
  const mttr = calcMTTR(incidents);

  return { deploymentFrequency, leadTime, changeFailureRate, mttr };
}

async function getPluginsInfo() {
  const plugins = loadPlugins();
  return plugins.map(p => ({ name: p.name, provides: Object.keys(p).filter(k=>k.startsWith('fetch')) }));
}

module.exports = { getDoraMetrics, getPluginsInfo };
