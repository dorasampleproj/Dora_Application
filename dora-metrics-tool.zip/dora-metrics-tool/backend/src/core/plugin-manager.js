
const fs = require('fs');
const path = require('path');

const pluginsDir = path.join(__dirname, '..', 'plugins');

function loadPlugins() {
  const plugins = [];
  if (!fs.existsSync(pluginsDir)) return plugins;

  fs.readdirSync(pluginsDir, { withFileTypes: true })
    .filter(d => d.isDirectory())
    .forEach(dir => {
      const entry = path.join(pluginsDir, dir.name, 'index.js');
      if (fs.existsSync(entry)) {
        const plugin = require(entry);
        if (plugin && plugin.name) plugins.push(plugin);
      }
    });
  return plugins;
}

module.exports = { loadPlugins };
