
# DORA Metrics Tool (React + Node.js, Plugin Architecture)

A plug-in / plug-out DORA metrics aggregator with a React dashboard and a Node.js backend. 

## Features
- **Plugin framework** for integrations: GitHub, Jira, ServiceNow, Databricks, Excel
- **Unified DORA metrics API** (Deployment Frequency, Lead Time, Change Failure Rate, MTTR)
- **React dashboard** with charts
- **Vite dev server** with proxy to backend
- **Demo mode** to run without external credentials

## Quickstart

### 1) Prerequisites
- Node.js 18+
- npm 9+ (or yarn/pnpm)

### 2) Start in demo mode (no tokens needed)
```bash
# In one terminal
cd backend
cp .env.sample .env
# Ensure USE_DEMO_DATA=true
npm install
npm run dev

# In another terminal
cd ../frontend
npm install
npm run dev
```
- Frontend: http://localhost:5173
- Backend API: http://localhost:4000/api

### 3) Configure real integrations
Edit `backend/.env` with your credentials (see `.env.sample`). Then disable demo mode:
```
USE_DEMO_DATA=false
```

### 4) Docker (optional)
```bash
# from repo root
docker compose up --build
```
- Frontend: http://localhost:5173
- Backend: http://localhost:4000

## Structure
```
backend/        # Node.js Express API, plugin framework
frontend/       # React + Vite dashboard
```

## DORA Definitions
- **Deployment Frequency**: Deployments per day/week
- **Lead Time for Changes**: Time from commit/merge to production deploy
- **Change Failure Rate**: Failed deployments / total deployments
- **MTTR**: Mean time to recover from incidents

## License
MIT (example)
