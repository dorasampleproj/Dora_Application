
import axios from 'axios'

export async function getMetrics(){
  const { data } = await axios.get('/api/metrics')
  return data
}

export async function getPlugins(){
  const { data } = await axios.get('/api/plugins')
  return data
}
