
import React from 'react'

export default function MTTR({ data }){
  const color = data.minutes <= 60 ? '#22c55e' : data.minutes <= 180 ? '#f59e0b' : '#ef4444'
  return (
    <div className='card'>
      <h3>MTTR — Mean Time to Restore</h3>
      <div className='value' style={{color}}>{data.minutes} min</div>
      <div className='row'>
        <div className='badge'>Target: < 60 min (Team)</div>
      </div>
    </div>
  )
}
