
import React from 'react'

export default function LeadTime({ data }){
  const speed = data.avgHours <= 24 ? 'Fast' : data.avgHours <= 72 ? 'Medium' : 'Slow'
  const color = data.avgHours <= 24 ? '#22c55e' : data.avgHours <= 72 ? '#f59e0b' : '#ef4444'
  return (
    <div className='card'>
      <h3>Lead Time for Changes</h3>
      <div className='value' style={{color}}>{data.avgHours} h</div>
      <div className='row'>
        <div className='badge'>p50: {data.p50} h</div>
        <div className='badge'>p90: {data.p90} h</div>
        <div className='badge'>Speed: {speed}</div>
      </div>
    </div>
  )
}
