
import React from 'react'

export default function ChangeFailureRate({ data }){
  const color = data.rate <= 15 ? '#22c55e' : data.rate <= 30 ? '#f59e0b' : '#ef4444'
  return (
    <div className='card'>
      <h3>Change Failure Rate</h3>
      <div className='value' style={{color}}>{data.rate}%</div>
      <div className='row'>
        <div className='badge'>Failed: {data.failed}</div>
        <div className='badge'>Total: {data.total}</div>
      </div>
    </div>
  )
}
