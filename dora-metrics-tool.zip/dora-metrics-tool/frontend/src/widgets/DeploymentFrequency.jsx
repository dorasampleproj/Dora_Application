
import React from 'react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'

export default function DeploymentFrequency({ data }){
  return (
    <div className='card'>
      <h3>Deployment Frequency</h3>
      <div className='value'>{data.valuePerDay} / day</div>
      <div style={{height:200}}>
        <ResponsiveContainer width='100%' height='100%'>
          <LineChart data={data.series}>
            <CartesianGrid stroke='#1f2937'/>
            <XAxis dataKey='date' stroke='#94a3b8' hide/>
            <YAxis stroke='#94a3b8'/>
            <Tooltip contentStyle={{ background:'#0b1220', border:'1px solid #1f2937' }}/>
            <Line type='monotone' dataKey='count' stroke='#22d3ee' strokeWidth={2} dot={false}/>
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
