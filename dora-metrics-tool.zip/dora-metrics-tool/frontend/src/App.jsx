
import React from 'react'
import Dashboard from './pages/Dashboard'

export default function App(){
  return (
    <div className="container">
      <header>
        <h1>DORA Metrics Dashboard</h1>
        <p className="subtitle">Deployment Frequency • Lead Time • Change Failure Rate • MTTR</p>
      </header>
      <Dashboard />
      <footer>
        <small>Demo mode enabled unless configured. Customize styles in <code>src/styles.css</code>.</small>
      </footer>
    </div>
  )
}
