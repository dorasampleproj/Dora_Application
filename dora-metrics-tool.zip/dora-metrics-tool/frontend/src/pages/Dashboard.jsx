
import React, { useEffect, useState } from 'react'
import { getMetrics, getPlugins } from '../api/metricsAPI'
import DeploymentFrequency from '../widgets/DeploymentFrequency'
import LeadTime from '../widgets/LeadTime'
import ChangeFailureRate from '../widgets/ChangeFailureRate'
import MTTR from '../widgets/MTTR'

export default function Dashboard(){
  const [metrics, setMetrics] = useState(null)
  const [plugins, setPlugins] = useState([])
  const [error, setError] = useState(null)

  useEffect(() => {
    (async () => {
      try {
        const [m, p] = await Promise.all([getMetrics(), getPlugins()])
        setMetrics(m)
        setPlugins(p)
      } catch (e){
        setError(e.message)
      }
    })()
  }, [])

  if (error) return <div className='card'>Error: {error}</div>
  if (!metrics) return <div className='card'>Loading metrics…</div>

  return (
    <>
      <div className='row' style={{marginBottom:16}}>
        <div className='badge'>Plugins loaded: {plugins.map(p=>p.name).join(', ') || 'none'}</div>
      </div>
      <div className='grid'>
        <DeploymentFrequency data={metrics.deploymentFrequency} />
        <LeadTime data={metrics.leadTime} />
        <ChangeFailureRate data={metrics.changeFailureRate} />
        <MTTR data={metrics.mttr} />
      </div>
    </>
  )
}
